# How to run crowdfunding project

## Create `.env` file in the project directory

## You can use the following command to copy all the environment variables you need from the example file or just copy manually

`cp .env.example .env`

Add all required environment variables to the `.env` file you created.
